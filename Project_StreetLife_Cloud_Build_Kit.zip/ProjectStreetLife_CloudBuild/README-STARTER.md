# Project StreetLife — Unity Android Starter

An original, GTA-inspired third-person open-world prototype for Android. This is a starter kit, not a finished AAA game. It includes player movement, touch joystick, camera orbit, a simple procedural city, drivable vehicle prototype, mission trigger, minimap camera setup guidance, and local save/load.

## Recommended setup
- Unity 6 LTS (or another current Unity LTS version)
- 3D URP template
- Android Build Support installed through Unity Hub, including Android SDK & NDK Tools and OpenJDK
- Set **Active Input Handling** to **Both** or **Input Manager (Old)** in Project Settings > Player > Other Settings. These scripts use Unity's classic `Input` API for easy setup.
- Set platform to Android in File > Build Profiles (or Build Settings in older Unity versions).

## Folder structure
Copy `Assets/StreetLife/Scripts/` into your Unity project's `Assets/` folder.

```
Assets/
  StreetLife/
    Scripts/
      Player/
        ThirdPersonPlayer.cs
        VirtualJoystick.cs
        TouchLookArea.cs
      Vehicles/
        SimpleCarController.cs
        VehicleEnterExit.cs
      VehicleTouchButton.cs
      Missions/
        MissionTrigger.cs
      World/
        ProceduralCityBuilder.cs
      UI/
        MinimapFollow.cs
      Save/
        SaveManager.cs
    Editor/
      StreetLifeSceneSetup.cs
```

## Phase 1 — Build a playable scene (one-click editor setup)

After copying `Assets/StreetLife` into your Unity project, wait for scripts to compile. In the Unity top menu, select **StreetLife → Setup Playable Prototype Scene**. This creates and saves `Assets/StreetLifePrototype.unity` with a basic player, camera, procedural city, starter car, touch UI, mission marker, minimap camera, and save button.

Then press Play in the Editor. The prototype uses placeholder shapes, not realistic final assets. If the Unity Editor reports an API or UI package compatibility issue, check the notes below and use the manual setup section as a fallback.

## Manual scene setup reference



### 1. Create the project
1. Open Unity Hub → New Project → **Universal 3D (URP)**.
2. Name it `ProjectStreetLife`.
3. Copy the `Assets/StreetLife` folder from this starter ZIP into the project's `Assets` folder.
4. Open the scene and save it as `StreetLifePrototype`.

### 2. Create the player
1. Create an empty GameObject named `Player`.
2. Add a `CharacterController` component.
3. Add a Capsule child (or use a capsule primitive) and position it at `(0, 1, 0)` if it is a child. Remove any collider from the visual child if it overlaps the CharacterController.
4. Add `ThirdPersonPlayer` to `Player`.
5. Create a `Main Camera`, add `Camera` and `AudioListener` (Unity normally creates these), and add `TouchLookArea` to a full-screen transparent UI panel or configure camera drag input as described below.
6. Assign the camera Transform to the player's `cameraTransform` field. Set `cameraTarget` to a child empty object at `(0, 1.5, 0)` on Player.
7. On the player, assign a `VirtualJoystick` component to `moveJoystick` after creating the UI joystick.

### 3. Add touch controls
1. Create a Canvas (Screen Space - Overlay).
2. Create a bottom-left joystick background image, add `VirtualJoystick`, and set its `handle` to a child UI image. Keep the joystick background roughly 180×180 pixels.
3. Create a transparent UI Image covering the right half of the screen, enable **Raycast Target**, and add `TouchLookArea`. Set `lookSensitivity` to around `0.15` to start.
4. Add a UI Button labelled **Interact / Enter Car**. Wire its OnClick to `VehicleEnterExit.Interact`.
5. Optional: add UI buttons for Run and Save; connect to methods you add or call `SaveManager.SaveGame()` from a separate button handler.

### 4. Generate a simple city
1. Create an empty GameObject named `CityBuilder`.
2. Add `ProceduralCityBuilder`.
3. Use the Inspector defaults and press Play. It generates a small grid of roads and simple coloured building blocks at runtime.
4. Set `groundSize` to 250–400 for a larger test area. Keep building count modest on mobile.

### 5. Add a vehicle
1. Create a Cube named `Car`, scale it to `(1.8, 0.7, 3.5)`, position it on a road.
2. Add a `Rigidbody`, set mass to around `1200`, drag to `0.1`, angular drag to `1`.
3. Add `SimpleCarController` and `VehicleEnterExit`.
4. Create an empty child named `DriverSeat` at a suitable position near the car cabin and assign it to `driverSeat`.
5. Assign Player to `VehicleEnterExit.player` and the player camera to `VehicleEnterExit.playerCamera`.
6. Add primitive cylinders/cubes as wheels if desired. For this prototype the car uses arcade Rigidbody movement; it is not a full wheel-collider simulation.
7. Ensure the car has a collider. Use the car's root transform as the `vehicleRoot`.

### 6. Add a mission
1. Create a Cylinder or Cube named `MissionMarker`, place it somewhere in the city.
2. Add a collider and enable **Is Trigger**.
3. Add `MissionTrigger` and set `missionTitle` and `rewardCash`.
4. Make sure the Player has the `Player` tag (Inspector > Tag > Player).

### 7. Add a minimap
1. Create a new Camera named `MinimapCamera`, set Projection to Orthographic, Rotation X = 90, Y = 0, Z = 0, Orthographic Size = 35, and place it above the player.
2. Set its Clear Flags to Solid Color and Depth low / default.
3. Create a RawImage on the Canvas, make it a small square in the top-right, and assign a Render Texture to both the camera's Target Texture and RawImage's Texture. Create the Render Texture via Assets > Create > Render Texture.
4. Add `MinimapFollow` to the MinimapCamera and assign Player as target. If using a Render Texture, keep the camera enabled.

### 8. Save/load
1. Add `SaveManager` to an empty GameObject named `SaveManager`.
2. Add a UI Button labelled Save and connect it to `SaveManager.SaveGame()`.
3. To load automatically, enable `loadOnStart` in Inspector. Saving uses `PlayerPrefs` for a small local prototype. For a production game, use versioned save data and handle corrupted files.

### 9. Build an Android APK
1. File > Build Profiles > Android > Switch Platform.
2. Player Settings: set a unique Package Name, e.g. `com.yourstudio.streetlife`.
3. Set orientation to Landscape Left (recommended for driving games).
4. Under Other Settings, choose an appropriate Minimum API Level for your target devices.
5. Connect an Android device with USB debugging enabled, or select Build to create an APK.
6. Test on a real device. Reduce shadow quality, render scale, post-processing, and building count if performance is low.

## Controls
- Left virtual joystick: move character.
- Drag the right-side touch area: rotate camera.
- Keyboard fallback in Editor: WASD / arrow keys; mouse drag for camera (depending on focus).
- Enter/exit vehicle: connect a UI button to `VehicleEnterExit.Interact`.
- Driving on Android: hold the UI buttons configured with `VehicleTouchButton`.
- Save: connect a UI button to `SaveManager.SaveGame()`.

## Development phases
- **Phase 1 (this kit):** movement, camera, blockout city, arcade car, mission trigger, minimap setup, local save.
- **Phase 2:** proper character model and animations, traffic AI, polished driving physics, UI/mission HUD, audio.
- **Phase 3:** authored city districts, pedestrians, police/wanted system, mission chains, garage.
- **Phase 4:** profiling, device compatibility, accessibility, release build and store assets.

## Compatibility notes
- This kit uses Unity's classic Input API for keyboard fallback and EventSystem UI pointer events. In Project Settings > Player > Active Input Handling, choose **Both** or **Input Manager (Old)**.
- If you use Unity 6, `Rigidbody.linearVelocity` and `linearDamping` are supported. For older Unity releases, replace `linearVelocity` with `velocity` and `linearDamping` with `drag`.
- The Editor setup script uses Unity's built-in `Text` UI component to avoid an extra package dependency. If your project is configured for TextMeshPro-only UI, the scene still works with the built-in UI module if available.
- A first-time scene build may require a few seconds for asset compilation. If the custom menu does not appear, check the Console for compile errors.

## Important
This is a code starter and scene-building guide. It does not include licensed GTA assets, finished 3D models, animation clips, or a prebuilt APK. Use original or properly licensed assets. Test frequently on your target Android device.
