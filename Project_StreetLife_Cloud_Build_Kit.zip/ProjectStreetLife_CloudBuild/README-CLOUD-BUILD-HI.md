# Project StreetLife — Cloud APK Build (Hindi)

Yeh package Unity source project + GitHub Actions workflow hai. APK abhi prebuilt nahi hai. Build ko GitHub par chalane ke liye Unity Personal license secret configure karna zaroori hai; workflow tab tak successful nahi hoga jab tak valid `UNITY_LICENSE` secret add na ho. Cloud builds may also consume GitHub Actions minutes.

## Phone se try karne ka tareeqa

1. ZIP extract karna zaroori nahi ho sakta, lekin GitHub repository banate waqt ZIP ke **andar ki files** upload honi chahiye (folder ke andar ek aur folder nest na karein).
2. Browser mein https://github.com par sign in/create account karein.
3. New repository banayein, e.g. `ProjectStreetLife`.
4. `Add file` → `Upload files` se is project ke files/folders upload karein. `.github/workflows/android-apk.yml` bhi upload hona chahiye. Phone par hidden `.github` folder upload karna mushkil ho sakta hai; desktop-mode ya GitHub Codespaces ki zaroorat pad sakti hai.
5. Unity license secret setup karein: GitHub repo → Settings → Secrets and variables → Actions → New repository secret → Name `UNITY_LICENSE`, Value mein Unity Personal license file ka valid contents. License file Unity account ke rules ke mutabiq Unity Editor se activate/export karna hota hai. Is starter kit mein valid license included nahi hai. **Apna password, license file ya secret kisi ko chat mein mat bhejein.**
6. Repo → Actions → `Build Project StreetLife Android APK` → `Run workflow`.
7. Build pass hone par run ke summary mein `ProjectStreetLife-Android-APK` artifact download karein. ZIP artifact extract karke APK phone par install karein.

## Important limitations

- Is chat mein APK compile/test nahi hua hai.
- Cloud workflow Unity license, Unity version availability, project compilation aur Android toolchain par depend karta hai.
- Prototype uses placeholder shapes and basic controls; it is not a finished GTA-scale game.
- If the build fails, open the failed workflow and copy the first meaningful red error text (do not share any secrets).
