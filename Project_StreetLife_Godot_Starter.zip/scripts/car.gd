extends CharacterBody3D

var player_driving := false
var speed := 0.0
const MAX_SPEED := 18.0
const ACCEL := 12.0
const BRAKE := 18.0
const STEER := 1.5
var gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")

func _ready() -> void:
    add_to_group("streetlife_car")

func _physics_process(delta: float) -> void:
    if not is_on_floor():
        velocity.y -= gravity * delta
    if player_driving:
        var throttle := Input.get_action_strength("move_forward") - Input.get_action_strength("move_back")
        var steering := Input.get_action_strength("move_right") - Input.get_action_strength("move_left")
        if abs(throttle) > 0.01:
            speed = move_toward(speed,throttle * MAX_SPEED,ACCEL * delta)
        else:
            speed = move_toward(speed,0.0,BRAKE * delta)
        rotate_y(-steering * STEER * delta * clamp(abs(speed)/5.0,0.2,1.0))
        var forward := -global_transform.basis.z
        velocity.x = forward.x * speed
        velocity.z = forward.z * speed
    else:
        speed = move_toward(speed,0.0,BRAKE * delta)
        velocity.x = 0
        velocity.z = 0
    move_and_slide()
