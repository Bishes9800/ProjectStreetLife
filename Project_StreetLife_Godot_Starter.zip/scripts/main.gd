extends Node3D

const PLAYER_SCRIPT = preload("res://scripts/player.gd")
const CAR_SCRIPT = preload("res://scripts/car.gd")

var player: CharacterBody3D
var car: CharacterBody3D
var hud: Label
var mission_hud: Label

func _ready() -> void:
    _create_world()
    _create_player()
    _create_car()
    _create_hud()

func _create_world() -> void:
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-50, -25, 0)
    sun.light_energy = 1.1
    add_child(sun)
    _box("Ground", Vector3(0,-0.5,0), Vector3(100,1,100), Color(0.2,0.42,0.24))
    _box("Road", Vector3(0,0.02,0), Vector3(12,0.05,100), Color(0.13,0.14,0.16))
    _box("CrossRoad", Vector3(0,0.03,0), Vector3(100,0.05,10), Color(0.13,0.14,0.16))
    for i in range(-4,5):
        _box("RoadLine", Vector3(0,0.06,i*10), Vector3(0.18,0.02,4), Color(1,0.85,0.3))
    var rng := RandomNumberGenerator.new()
    rng.seed = 12
    for x in [-1,1]:
        for z in range(-4,5):
            var h := rng.randf_range(5,16)
            var w := rng.randf_range(4,8)
            var d := rng.randf_range(4,8)
            var bx := x * rng.randf_range(12,20)
            var bz := z * 10.0
            _box("Building", Vector3(bx,h/2,bz), Vector3(w,h,d), Color.from_hsv(rng.randf_range(0.03,0.12),0.2,0.65))
    var marker := Area3D.new()
    marker.name = "MissionMarker"
    marker.position = Vector3(0,0.2,-24)
    add_child(marker)
    var visual := MeshInstance3D.new()
    var cyl := CylinderMesh.new()
    cyl.top_radius = 1.5
    cyl.bottom_radius = 1.5
    cyl.height = 0.15
    visual.mesh = cyl
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(1,0.7,0.05)
    mat.emission_enabled = true
    mat.emission = Color(1,0.45,0)
    visual.material_override = mat
    marker.add_child(visual)
    var cs := CollisionShape3D.new()
    var shape := CylinderShape3D.new()
    shape.radius = 1.6
    shape.height = 2.0
    cs.shape = shape
    cs.position.y = 1.0
    marker.add_child(cs)
    marker.body_entered.connect(_on_mission_entered)

func _create_player() -> void:
    player = CharacterBody3D.new()
    player.name = "Player"
    player.position = Vector3(0,1.1,8)
    player.set_script(PLAYER_SCRIPT)
    add_child(player)
    var visual := MeshInstance3D.new()
    var capsule := CapsuleMesh.new()
    capsule.radius = 0.42
    capsule.height = 1.8
    visual.mesh = capsule
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.1,0.4,0.95)
    visual.material_override = mat
    player.add_child(visual)
    var cs := CollisionShape3D.new()
    var shape := CapsuleShape3D.new()
    shape.radius = 0.42
    shape.height = 1.8
    cs.shape = shape
    player.add_child(cs)
    var pivot := Node3D.new()
    pivot.name = "CameraPivot"
    pivot.position = Vector3(0,1.25,0)
    player.add_child(pivot)
    var cam := Camera3D.new()
    cam.name = "Camera3D"
    cam.position = Vector3(0,2.5,6.5)
    cam.rotation_degrees.x = -15
    cam.current = true
    pivot.add_child(cam)

func _create_car() -> void:
    car = CharacterBody3D.new()
    car.name = "Car"
    car.position = Vector3(3.2,0.65,5)
    car.set_script(CAR_SCRIPT)
    add_child(car)
    _child_box(car,"Body",Vector3(0,0.1,0),Vector3(2,0.65,3.6),Color(0.8,0.1,0.08))
    _child_box(car,"Cabin",Vector3(0,0.65,-0.15),Vector3(1.4,0.7,1.6),Color(0.12,0.18,0.22))
    var cs := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = Vector3(2,1.5,3.6)
    cs.shape = shape
    cs.position.y = 0.2
    car.add_child(cs)

func _create_hud() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    hud = Label.new()
    hud.position = Vector2(18,15)
    hud.add_theme_font_size_override("font_size",20)
    hud.text = "PROJECT STREETLIFE  |  WASD Move • Shift Run • Space Jump • E Car"
    layer.add_child(hud)
    mission_hud = Label.new()
    mission_hud.position = Vector2(18,48)
    mission_hud.add_theme_font_size_override("font_size",20)
    mission_hud.add_theme_color_override("font_color",Color(1,0.8,0.15))
    mission_hud.text = "MISSION: Reach the yellow marker"
    layer.add_child(mission_hud)

func _box(n: String, pos: Vector3, size: Vector3, color: Color) -> void:
    var mi := MeshInstance3D.new()
    mi.name = n
    var mesh := BoxMesh.new()
    mesh.size = size
    mi.mesh = mesh
    mi.position = pos
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mi.material_override = mat
    add_child(mi)
    var body := StaticBody3D.new()
    body.position = pos
    var cs := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = size
    cs.shape = shape
    body.add_child(cs)
    add_child(body)

func _child_box(parent: Node3D, n: String, pos: Vector3, size: Vector3, color: Color) -> void:
    var mi := MeshInstance3D.new()
    mi.name = n
    var mesh := BoxMesh.new()
    mesh.size = size
    mi.mesh = mesh
    mi.position = pos
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mi.material_override = mat
    parent.add_child(mi)

func _on_mission_entered(body: Node3D) -> void:
    if body == player:
        mission_hud.text = "MISSION COMPLETE!"
