extends CharacterBody3D

const WALK_SPEED := 5.0
const RUN_SPEED := 8.5
const JUMP_VELOCITY := 5.0
var gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")
var driving := false
var active_car: CharacterBody3D

func _physics_process(delta: float) -> void:
    if driving:
        visible = false
        if Input.is_action_just_pressed("interact") and is_instance_valid(active_car):
            driving = false
            active_car.player_driving = false
            global_position = active_car.global_position + active_car.global_transform.basis.x * 2.5 + Vector3.UP
            visible = true
        return
    if not is_on_floor():
        velocity.y -= gravity * delta
    if Input.is_action_just_pressed("jump") and is_on_floor():
        velocity.y = JUMP_VELOCITY
    var input_dir := Input.get_vector("move_left","move_right","move_forward","move_back")
    var direction := (global_transform.basis * Vector3(input_dir.x,0,input_dir.y)).normalized()
    var speed := RUN_SPEED if Input.is_action_pressed("sprint") else WALK_SPEED
    if direction:
        velocity.x = direction.x * speed
        velocity.z = direction.z * speed
    else:
        velocity.x = move_toward(velocity.x,0.0,speed)
        velocity.z = move_toward(velocity.z,0.0,speed)
    move_and_slide()
    if Input.is_action_just_pressed("interact"):
        var candidate := get_tree().get_first_node_in_group("streetlife_car")
        if candidate and global_position.distance_to(candidate.global_position) < 4.0:
            active_car = candidate
            driving = true
            active_car.player_driving = true
