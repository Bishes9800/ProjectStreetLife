# Project StreetLife — Godot Starter

A code-generated Godot 4.x 3D prototype with a simple city block, player capsule, drivable car, mission marker, and HUD. It uses placeholder shapes, not finished game assets.

## Open
1. Download and extract this ZIP.
2. Install Godot 4 Standard: https://godotengine.org/download/windows/
3. In Godot Project Manager, choose Import and select `project.godot`.
4. Press F6/F5 to run.

## Controls
- WASD: move
- Shift: sprint
- Space: jump
- E: enter/exit nearby car
- While driving, WASD controls the car

## Android
Android APK export needs Godot export templates and Android SDK/JDK. Follow:
https://docs.godotengine.org/en/stable/tutorials/export/exporting_for_android.html

This is starter source code, not a finished GTA-scale game and not a prebuilt APK. The scripts have not been run through Godot in this environment.
